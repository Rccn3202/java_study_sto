package ch02.sec01;

public class IntegerLiteralExample {
	public static void main(String[] args) {
		int var1 = 0b1011;
		int var2 = 0206;
		int var3 = 365;
		int var4 = 0xB3;
	
		System.out.println("var1: " + var1);
		System.out.println("var2: " + var2);
		System.out.println("var3: " + var3);
		System.out.println("var4: " + var4);
		
		char aWord='a';
		System.out.println();
	}
}
char aWord='a';
System.out.println ( (char) (aWord -32));	
