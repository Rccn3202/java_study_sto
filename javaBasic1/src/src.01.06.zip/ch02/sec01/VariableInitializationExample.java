package ch02.sec01;

public class VariableInitializationExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int value=5;
		int result = value + 10; //initialize value 
		
		System.out.println(result);

	}

}
