package ch02.sec01;

public class VariableUseExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int hour = 3;
		int minute = 5;
		System.out.println(hour + "�ð� " + minute + "��");
		
		int totalMinute = (hour*60) + minute;
		System.out.println("�� " + totalMinute + "��");

	}

}
