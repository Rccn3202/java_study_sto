package ch02.sec01;

public class s {

	public static void main(String[] args) {
	
		    int x, y, sum;

		    Scanner scan = new Scanner(System.in);

		    System.out.println("���� �Է�:");

		    x = scan.nextInt();



		    System.out.println("���� �Է�:");

		    y = scan.nextInt();



		    sum = x + y;

		    System.out.println("�հ�: " + sum);

		    scan.close();

		  }

		}
	}

}
