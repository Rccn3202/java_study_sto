package exBasic;

public class MySecond {

	public static void main(String[] args) {
	
			String a; //자
			String b; //시
			String c; //객
			
			a = "자바는";
			b = "시스템에 독립적인";		
			c = "객체지향 프로그래밍 언어이다";
	
			String line1;
			line1="자바는";
			
			String line2 = "자바는";
			String line3 = "시스템에 독립적인", line4 = "객체지향 프로그래밍 언어이다";
	
			System.out.println(line2);
			System.out.println(line3);
			System.out.println(line4);
			
			System.out.println("자바는\n 시스템에 독립적인\n 객체지향");
	}

}
