package javaBasic1;

import java.util.Scanner;

public class VarEx333 {

	String name="홍길동";
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); //클래스 2개 쓴 것(대문자)
	}

}


class VarEx111{
	int kor = 100;
}

class kk{
	boolean ox=true;
}

