package javaBasic1;

public class VarEx4 {

}
